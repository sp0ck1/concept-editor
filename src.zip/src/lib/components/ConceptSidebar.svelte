import ConceptTagsPreview from '$lib/components/tags/ConceptTagsPreview.svelte';
import type { Concept } from '$lib/types/Concept';
import type { ConceptCardView } from '$lib/types/ConceptCardView';

let {
	sidebarTab,
	mainView,
	currentCanvasCard,
	sidebarNewTag,
	getTagConcepts,
	onSidebarTabChange,
	onTitleKeydown,
	onTitleBlur,
	onSidebarNewTagChange,
	onSidebarTagAdd,
	onTagOpen,
	onTagRemove
} = $props<{
	sidebarTab: 'concept' | 'tree';
	mainView: 'canvas' | 'table';
	currentCanvasCard: ConceptCardView | null;
	sidebarNewTag: string;
	getTagConcepts: (tagConceptIds: string[]) => Concept[];
	onSidebarTabChange: (tab: 'concept' | 'tree') => void;
	onTitleKeydown: (event: KeyboardEvent, card: ConceptCardView) => void;
	onTitleBlur: (event: FocusEvent, card: ConceptCardView) => void;
	onSidebarNewTagChange: (value: string) => void;
	onSidebarTagAdd: (card: ConceptCardView) => void;
	onTagOpen: (tagConcept: Concept) => void;
	onTagRemove: (card: ConceptCardView, tagConcept: Concept) => void;
}>();

<aside class="concept-sidebar" aria-label="Concept sidebar">
			<div class="sidebar-tabs" role="tablist" aria-label="Sidebar tabs">
				<button
					class:active={sidebarTab === 'concept'}
					type="button"
					role="tab"
					aria-selected={sidebarTab === 'concept'}
					onclick={() => {
						sidebarTab = 'concept';
					}}
				>
					Concept
				</button>

				<button
					class:active={sidebarTab === 'tree'}
					type="button"
					role="tab"
					aria-selected={sidebarTab === 'tree'}
					onclick={() => {
						sidebarTab = 'tree';
					}}
				>
					Tree
				</button>
			</div>

			{#if sidebarTab === 'concept'}
				<div class="sidebar-panel">
					{#if currentCanvasCard}
						{@const sidebarCard = currentCanvasCard}

						<div class="sidebar-section">
							<!-- <div class="sidebar-label">Current Concept</div>-->
							<h2 class="sidebar-title"></h2>
							<input
								class="sidebar-title-input"
								value={sidebarCard.concept.title}
								placeholder="Untitled Concept"
								aria-label="Concept title"
								onkeydown={(event) => handleConceptTitleKeydown(event, sidebarCard)}
								onblur={(event) => handleConceptTitleBlur(event, sidebarCard)}
							/>

							<div class="sidebar-id">
								{sidebarCard.instance.id}
							</div>

							<div class="tag-label-row">
								<div class="sidebar-label">Tags</div>

								<input
									class="concept-tag-input sidebar-tag-input"
									bind:value={sidebarNewTag}
									placeholder="+ tag"
									aria-label="Add tag"
									onkeydown={(event) => {
										if (event.key === 'Enter') {
											event.preventDefault();
											event.stopPropagation();
											addSidebarTag(sidebarCard);
										}
									}}
									onblur={() => addSidebarTag(sidebarCard)}
								/>
							</div>

							<ConceptTagsPreview
								tags={getTagConcepts(sidebarCard.concept.tagConceptIds ?? [])}
								showInput={false}
								onTagOpen={openTagCanvas}
								onTagRemove={(tagConcept) => handleTagRemove(sidebarCard, tagConcept)}
							/>
						</div>

						<!-- 						
						<div class="sidebar-section">
							<ConceptImportPanel
								targetConceptName={sidebarCard.concept.title || sidebarCard.concept.id}
								onImport={createConceptsFromParsedItems}
							/>
						</div> -->

						<div class="sidebar-section">
							<div class="sidebar-label">Properties</div>

							{#if Object.entries(sidebarCard.concept.properties ?? {}).length === 0}
								<div class="sidebar-empty">No properties yet.</div>
							{:else}
								<div class="sidebar-property-list">
									{#each Object.entries(sidebarCard.concept.properties ?? {}) as [key, value]}
										<div class="sidebar-property-row">
											<div class="sidebar-property-key">{key}</div>
											<div class="sidebar-property-value">{value}</div>
										</div>
									{/each}
								</div>
							{/if}
						</div>
					{:else}
						<div class="sidebar-section">
							<div class="sidebar-label">Current Canvas</div>
							<h2 class="sidebar-title">Root</h2>
							<p class="sidebar-note">
								This is the root view. Enter a concept to take a closer look at its properties and
								child concepts.
							</p>
						</div>
					{/if}
				</div>
			{:else}
				<div class="sidebar-panel">
					<div class="sidebar-section">
						<div class="sidebar-label">Tree View</div>
						<h2 class="sidebar-title">Tree</h2>
						<p class="sidebar-note">
							Tree view will live here later. It should derive from concept instances and
							parentInstanceId.
						</p>
					</div>
				</div>
			{/if}
		</aside>